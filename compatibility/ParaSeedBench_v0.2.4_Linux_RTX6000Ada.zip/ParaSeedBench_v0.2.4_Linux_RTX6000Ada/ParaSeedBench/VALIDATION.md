# Validation record

This record separates software checks actually run from experiments not performed.

## Completed in the editor's Linux environment

- Version 0.2.2 baseline: 35 pytest tests passed (nine legacy tests and 26 v2 cases).
- Simulated generation interruption: one committed image survives; restart computes
  only nine pending images; another restart computes none; corrupting one PNG causes
  only that image to be repaired.
- Simulated evaluator interruption: the first image score is retained; only the nine
  missing scores are recomputed; a subsequent run performs no evaluator calls.
- Interrupted atomic JSON writes preserve the previous checkpoint.
- Image digest/job checks and single-writer lock behavior pass.
- DINO batch token/path validation and corrupted-chunk rejection pass.
- Missing entire scene, seed, variant, model, or single cell fails final analysis.
- Binary-state and duplicate-row validation pass.
- Main/development prompt specifications, including controls, are disjoint.
- Analytical finite-grid variance identities agree with direct Hamming distances.
- Constant-correct, constant-wrong, wording-only, seed-only, and XOR cases pass.
- JSD matches full-state-support smoothing; cross-fit selected-worst logic passes.
- Category-balanced bootstrap and undefined-diversity behavior pass.
- Human audit sampling is independent of machine pass/fail and incomplete states fail.
- Synthetic complete-grid analysis produces tables, CSVs, and a confidence-interval plot.
- Python source compilation passes; a no-dependency wheel build succeeds.
- Manuscript compiles with the official ICASSP 2027 spconf.sty: five US Letter pages,
  technical content only on pages 1-4, references on page 5, no page numbers.
- PDF pages visually inspected; all listed fonts embedded as Type 1, no Type 3 fonts.
- Version 0.2.3 focused regressions passed for explicit PixArt caption cleaning,
  fixed slow-processor settings, split/count provenance, synthetic analysis, and
  human-readable table/figure labels. Python source compilation passed.
- Version 0.2.4 source compilation and a focused two-rater regression passed: a
  disagreement blocks the human-primary gate, exact disagreement-only adjudication
  resolves it, and development-sized audits remain barred from paper export.

## User-supplied RTX 6000 Ada evidence

- Version 0.2.2 completed a 480-image development grid: 160 images for each of
  SD 1.5, SDXL, and PixArt-Sigma, followed by 480 semantic evaluations and 60
  DINO batches.
- The supplied development artifacts contain 16 scenes and 48 model-scene rows.
  Independent checks found no duplicate keys, non-finite numeric values, invalid
  intervals, or violations of the exact variance/disagreement identities.
- The live log exposed environment-dependent PixArt caption cleaning and an
  impending image-processor default change. Version 0.2.3 froze the effective
  development behavior explicitly.
- The supplied 192-image single-rater audit found overall machine--human joint-label
  agreement 0.781, recall 0.484, specificity 0.923, balanced accuracy 0.703, and
  Cohen's kappa 0.449. This validates the v0.2.4 decision to make resolved human
  atomic labels primary and automatic labels secondary.

Synthetic outputs and mock GPU outputs are test fixtures, never paper measurements.

## Not validated here

- No v0.2.4 RTX 3070/RTX 6000 Ada CUDA generation was run in the editor environment.
- No live Windows PowerShell, Colab runtime, or Google Drive interruption was tested.
- No native-resolution SDXL experiment or measured throughput benchmark was run.
- PixArt's split-repository composition is covered by a loader-wiring unit test;
  live Hub download and CUDA inference were not available in the editor environment.
- PixArt scheduler provenance is regression-tested with nested `-inf`, `+inf`,
  and `NaN`: raw non-standard JSON is still rejected and tagged JSON round-trips.
- No second independent human annotation or blinded adjudication was supplied; the
  completed development audit is therefore provisional rather than paper-primary.
- The complete pytest suite was not rerun after the v0.2.4 patch because pytest is
  unavailable in the editor runtime; focused regressions and source compilation passed.
- Local atomic replacement does not prove remote/cloud durability or exact mid-step recovery.

Run the v2 smoke test on the intended GPU before committing to the main experiment.
Do not interpret a passing unit test or successful PDF compile as empirical validation.

$ErrorActionPreference = "Stop"

python -m paraseedbench.generate --config configs/main.yaml
python -m paraseedbench.evaluate --input outputs/main
python -m paraseedbench.embed --input outputs/main --batch-size 8
python -m paraseedbench.analyze `
  --scores outputs/main/semantic_scores.csv `
  --embeddings outputs/main/dino_embeddings.npz `
  --output-dir outputs/main/analysis `
  --paper-table manuscript/generated/results_table.tex

Write-Host "Main analysis complete. Recompile manuscript/main.tex."

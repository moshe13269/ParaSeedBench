# ParaSeedBench v2: install, validate, run, resume

Version 0.2.4. Human-primary audit revision, September 2026.

Patch 0.2.4 responds to the completed 192-image development audit. Joint
machine--human accuracy was 0.781, but joint recall was only 0.484 and agreement
changed important seed/wording conclusions. Automatic semantic results are therefore
secondary diagnostics. A paper export now requires a prespecified main human audit
with at least four scenes per category, two independent raters, and resolved atomic
disagreements. The scorer reports joint, atomic-bit, and exact-state agreement,
machine--human metric changes, and a guarded human-primary LaTeX table.

Patch 0.2.3 removes two environment-dependent preprocessing choices observed in
the live RTX 6000 Ada development run. The PixArt call now freezes
`clean_caption: false`, so installing or omitting BeautifulSoup cannot change the
prompt text. OWLv2 and DINO processors now freeze `use_fast: false`, preserving
the processor used by the development run even if a future Transformers release
changes its default. Analysis metadata records the split, scene/seed counts, and
images per model, and generated table/figure labels use publication names.

Patch 0.2.2 handles non-finite constants in third-party scheduler provenance.
PixArt's scheduler legitimately exposes `-inf`; the runner now stores a tagged,
standards-compliant JSON representation while leaving the live scheduler object
unchanged. Strict JSON validation remains enabled for every checkpoint.

Patch 0.2.1 fixes PixArt-Sigma loading. The 512-MS Hub repository contains only
the denoising transformer and therefore has no `model_index.json`. The runner now
loads that pinned transformer into the complete, separately pinned 1024-MS
PixArt-Sigma pipeline (T5, VAE, tokenizer, and scheduler). VAE slicing is also
disabled as declared, avoiding the deprecated unconditional call in 0.2.0.

The manuscript is still a draft, **not a completed main-results paper**. The supplied
RTX 6000 Ada development run and one-rater development audit are documented as pilot
evidence. Main generation, two-rater main annotation, adjudication, and author review
remain required. Editor-side software tests use synthetic data and simulated interruptions.

## 1. Preserve your current experiment

Extract this package into a **new folder**. Do not replace scripts under a running
process or overwrite `outputs/main` from v1. Keep its configuration and environment.
V2 changes prompts and exact-count requirements, evaluator semantics, censor handling,
and provenance. Existing v1 images are useful for exploratory diagnosis, but cannot
be silently renamed or merged into the v2 paper grid. The package never deletes them.
Old entry points and `README_v1_legacy.md` remain for reference; use only v2 commands below.

## 2. Windows installation

You previously showed Python 3.10 installed; it is supported (3.10-3.12).
From the NEW extracted `ParaSeedBench` directory in PowerShell:

```powershell
py -3.10 -m venv .venv
Set-ExecutionPolicy -Scope Process Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

Install CUDA-enabled PyTorch and torchvision using the Windows/Pip command from
the official selector: https://pytorch.org/get-started/locally/ . Match your driver;
do not install a CPU wheel. If using an existing configured Linux/PyTorch container,
keep its CUDA-enabled torch installation rather than replacing it indiscriminately.

Then:

```powershell
python -m pip install -e ".[test]"
python -m paraseedbench.check_install
python -m pytest -q
python -m paraseedbench.suite_v2
```

The suite generator verifies existing data and refuses different contents; it does
not overwrite edited prompts. If you edit prompts, preserve their own version and
freeze that file rather than rebuilding it over your changes.

### Linux / RTX 6000 Ada installation

If `python3 -m venv` is available:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Without `sudo` or the Ubuntu `python3-venv` package, use `virtualenv` and reuse an
existing CUDA-enabled system PyTorch installation:

```bash
python3 -m pip install --user --upgrade virtualenv
python3 -m virtualenv --system-site-packages .venv
source .venv/bin/activate
```

Then install and validate. `--no-build-isolation` avoids older corporate package
mirrors supplying a build backend without the editable-install hook.

```bash
python -m pip install --upgrade pip "setuptools>=68" wheel
python -m pip install --no-build-isolation -e ".[test]"
python -m paraseedbench.check_install
python -m pytest -q
```

## 3. Select hardware BEFORE starting a new run

Included profiles:

| File | GPU placement | Purpose |
| --- | --- | --- |
| `configs/main_v2.yaml` | All models resident | RTX 6000 Ada, main grid |
| `configs/smoke_v2.yaml` | All models resident | Four development scenes, two seeds |
| `configs/dev_v2.yaml` | All models resident | 16 development scenes, two seeds |
| `configs/main_v2_rtx3070.yaml` | Model/sequential offload | 8 GB RTX 3070, main grid |

To create a new 3070 smoke profile:

```powershell
python -m paraseedbench.config_v2 --hardware rtx3070 --split smoke --output configs/smoke_3070.yaml
```

Do not enable xFormers, change placement, precision, seed lists, or package versions
halfway through a run. V2 disables attention slicing and uses the pipeline's default
attention processor; adding slicing on top of SDPA can slow inference. No throughput
guarantee is made. Measure seconds/image after warmup for each model; multiply by
remaining images and add evaluation time. Both profiles need substantial host RAM
for loading checkpoints, particularly PixArt's text encoder.

## 4. Freeze and run the smoke test

The freeze step contacts Hugging Face to resolve immutable commits for all generator,
detector, color-classifier and embedding checkpoints. For PixArt it freezes both the
512-MS transformer repository and the complete component-pipeline repository. It does
not download weights or fabricate version IDs. It refuses to overwrite an existing
locked configuration.

```powershell
python -m paraseedbench.freeze_v2 --config configs/smoke_v2.yaml --output configs/smoke_v2.lock.yaml
python -u -m paraseedbench.run_v2 --config configs/smoke_v2.lock.yaml
```

Smoke = 4 x 5 x 2 x 3 = 120 saved images, plus repeatability-check generations.
It runs all stages. Verify image quality, color/count/spatial labels, censoring,
memory, and speed on your actual GPU. GPU inference was NOT tested by the editor.

If a 0.2.0 smoke run stopped with a PixArt `model_index.json` 404, its completed
SD1.5/SDXL images remain intact. Do not edit its frozen configuration or manifest.
Install 0.2.1 in a new project folder and run a newly frozen smoke configuration;
the Hub cache is shared, so the large SD1.5/SDXL downloads are reused. Regenerating
those 80 smoke images is intentional because the source contract changed.

Likewise, if a 0.2.1 smoke run stopped while saving PixArt pipeline metadata with
`Out of range float values are not JSON compliant: -inf`, install 0.2.2 in a new
project folder and create a new frozen run. All model downloads are retained in
the shared Hub cache; only the short smoke generations are repeated.

If a 0.2.2 development run completed with repeated `clean_caption` or `use_fast`
warnings, preserve it as diagnostic evidence. Install 0.2.3 in a new folder and
freeze a new development config before main. The observed v0.2.2 fallbacks were
already false/slow, but rerunning the short development grid gives the main study
an explicit, matching contract. Cached model weights are reused.

If the v0.2.3 development run and audit already completed, install v0.2.4 in a new
project folder and rerun only the audit scoring command against the existing audit
directory. No GPU generation is needed for that rescore. Do not start a main run with
v0.2.3: Python source is part of the immutable run contract, so freeze the main config
from v0.2.4 into a new lock file and use a new main output directory.

From the v0.2.4 project, point the scorer at the absolute v0.2.3 run path:

```bash
V023_DEV_RUN="/absolute/path/to/v0.2.3/project/outputs/v2_dev_rtx6000ada"
python -m paraseedbench.audit_v2 \
  --input "$V023_DEV_RUN" \
  --output "$V023_DEV_RUN/audit_gate" \
  --human "$V023_DEV_RUN/audit_gate/human_dev_a.csv"
```

## 5. Review development evidence, then freeze main

Every prompt group needs independent semantic review. The v2 prompts correct known
v1 problems but are not human-certified. The 16 development scenes are separate
from the main suite (including controls); they use extra nouns, which is a calibration
domain limitation. The smoke set is a subset of development, never main.

Use `dev_v2.yaml` in the same freeze/run commands only if a fresh v0.2.4 development
run is needed. The supplied audit did not validate the automatic evaluator, so v0.2.4
retains its thresholds as declared defaults. Main output must not guide thresholds or
wording edits.

Automatic development scores are not calibration labels: a generator can violate
both a base prompt and its counterfactual. Counterfactual success therefore diagnoses
the generator/evaluator pair but cannot by itself establish detector validity. Before
freezing main, create a blinded development audit. Two scenes per category produce
192 images because the development grid has two seeds:

```bash
python -m paraseedbench.audit_v2 \
  --input outputs/v2_dev_v024_rtx6000ada \
  --output outputs/v2_dev_v024_rtx6000ada/audit_gate \
  --scenes-per-category 2 --seed 2027
```

Give a reviewer `index.html`, `images/`, and a copy of `annotations.csv`, but never
`PRIVATE_machine_key.csv`. After annotation, score the labels:

```bash
python -m paraseedbench.audit_v2 \
  --input outputs/v2_dev_v024_rtx6000ada \
  --output outputs/v2_dev_v024_rtx6000ada/audit_gate \
  --human outputs/v2_dev_v024_rtx6000ada/audit_gate/human_dev_a.csv
```

Version 0.2.4 labels this one-rater result `human_provisional` and reports automatic
results as `automatic_secondary`. Inspect `machine_human_agreement.csv`, including
atomic-bit and exact-state agreement, and `machine_human_metric_differences.csv`.
The supplied development audit showed material errors, so the paper protocol does not
treat the automatic evaluator as a primary endpoint. Do not retune thresholds on the
main images or present the development subset as confirmatory model evidence.

For the main audit, give `annotations_rater_a.csv` and `annotations_rater_b.csv`
to different reviewers and have them save their completed files as `human_a.csv`
and `human_b.csv`. Reviewers must not see each other's labels or the private key.

```powershell
python -m paraseedbench.freeze_v2 --config configs/main_v2.yaml --output configs/main_v2.lock.yaml
python -u -m paraseedbench.run_v2 --config configs/main_v2.lock.yaml
```

Or `./run_v2.ps1 -Config configs/main_v2.lock.yaml` on Windows,
or `bash run_v2.sh configs/main_v2.lock.yaml` on Linux/Colab.
These use a single Python orchestrator: an exception stops the pipeline. A failure
cannot fall through to a misleading “analysis complete” message.

Main = 96 scenes x 5 prompts x 8 seeds x 3 models = 11,520 saved images.
Additional repeatability probes: 4 scenes x 2 identical calls x 3 models = 24 images
computed but not added to the statistical grid. Probes validate same-process pixel
repeatability, not cross-platform determinism or semantic faithfulness.

For an unattended Linux workstation run, activate the intended environment and start
the same orchestrator under `nohup`:

```bash
nohup python -u -m paraseedbench.run_v2 \
  --config configs/main_v2.lock.yaml > main_weekend.log 2>&1 &
echo $! > main_weekend.pid
```

This survives an SSH logout, not a reboot or power loss. After a stopped process,
clear a stale writer lock as described below and rerun the identical locked config;
validated checkpoints are retained.

## 6. Restart after interruption

Activate the SAME environment, return to the SAME project directory, and rerun:

```powershell
python -u -m paraseedbench.run_v2 --config configs/main_v2.lock.yaml
```

| Stage | Commit unit | On restart |
| --- | --- | --- |
| Generation | PNG plus SHA-256 metadata, metadata committed last | Validate bytes and job; recompute incomplete/corrupt image |
| Evaluation | One atomic JSON per image | Reuse matching image/evaluator hash; recompute unfinished image |
| DINO | One atomic NPZ per batch (default eight) | Reuse matching batch; recompute incomplete/corrupt batch |
| Tables/analysis | Derived products | Rebuild from complete validated checkpoints |

This resumes **completed work**, not the middle of a denoising step. Temporary
files may remain after process death; they are never treated as completed results.
Source/config/dataset/model revisions, software versions, GPU model, CUDA and cuDNN
are guarded. A mismatch stops rather than silently mixing environments. The contract
does not fingerprint every system detail (e.g., all driver/library binaries).

A killed process can leave `.run.lock`. ONLY after confirming the previous process
is stopped, remove the lock using this explicit command, then rerun normally:

```powershell
python -m paraseedbench.run_v2 --config configs/main_v2.lock.yaml --clear-stale-lock
```

This removes the writer lock only, never images. Do not clear a lock while another
process writes the same directory. Monitor progress read-only with:

```powershell
python -m paraseedbench.run_v2 --config configs/main_v2.lock.yaml --stage status
nvidia-smi -l 2
```

An output-directory change alone is allowed for relocation because file paths are
relative to the run root. You must copy the complete run and preserve the locked
config and software. Different GPUs/OS/package versions are NOT interchangeable.

## 7. Colab persistence

Use the v2 Python commands in notebook cells, not PowerShell scripts. Put `output_dir`
in your mounted Drive BEFORE the first run, for example
`/content/drive/MyDrive/ParaSeedBench_v2/main`. Keep the locked YAML and package copy
in Drive too. Reconnect, mount Drive, restore the same code/environment, and rerun.
Do not delete any local output directory as a setup step. Keep regular backup archives.

Atomic file replacement helps on local filesystems, but **is not a guarantee that
Google Drive has synchronized bytes before a runtime is deleted**. Missing/corrupt
commits are revalidated on restart. A different Colab GPU or package stack causes an
intentional contract error. There is no keep-alive hack, automatic runtime restart,
or guaranteed multi-day background execution in this package. Follow Colab's own
runtime and paid-plan limits: https://research.google.com/colaboratory/faq.html .
For an uninterrupted experiment on your RTX 6000 Ada, the workstation avoids this
specific changing-runtime problem. Two GPUs are not automatically used.

## 8. Censoring and black outputs

V2 retains the model-native safety filter and records its flag. All-black outputs
are also flagged. They remain in the intended denominator as end-to-end pipeline
failures, with censor/black rates and conditional uncensored accuracy reported
separately. Never reroll just the flagged seeds. A black output is not automatically
proof of a safety-filter false positive; numerical faults can also produce black images.
Do not apply the earlier safety-checker-removal snippet to v2. A generator-only
uncensored study would be a separate, explicitly declared protocol and new run.

## 9. Human-primary main audit

After main automatic analysis:

```bash
python -m paraseedbench.audit_v2 \
  --input outputs/v2_main_v024_rtx6000ada \
  --output outputs/v2_main_v024_rtx6000ada/audit \
  --scenes-per-category 4 --seed 2027
```

This prespecified audit selects 16 complete scene grids shared across all models:
1,536 images per annotator. Four scene clusters per category still give limited
uncertainty, but the earlier eight-scene design is too weak for a primary paper table.
Give reviewer A `index.html`, `images/`, and `annotations_rater_a.csv`; give reviewer B
the same HTML/images and only `annotations_rater_b.csv`. Do not expose either person's
labels or `PRIVATE_machine_key.csv` before both independent files are complete.

Fill `human_atom_state` as text (for example `0110`, retaining leading zeros). Each
digit follows the atom order in the HTML. The scorer rejects partial grids, malformed
labels, and missing/duplicate IDs. First compute inter-rater and provisional outputs:

```bash
python -m paraseedbench.audit_v2 \
  --input outputs/v2_main_v024_rtx6000ada \
  --output outputs/v2_main_v024_rtx6000ada/audit \
  --human outputs/v2_main_v024_rtx6000ada/audit/human_a.csv \
  --second-human outputs/v2_main_v024_rtx6000ada/audit/human_b.csv
```

If atomic states differ, the command writes `adjudication.html` and
`adjudication_blank.csv` containing only disagreement IDs. Copy the blank file to
`human_adjudicated.csv`, independently adjudicate every listed state without consulting
automatic labels, and rerun:

```bash
python -m paraseedbench.audit_v2 \
  --input outputs/v2_main_v024_rtx6000ada \
  --output outputs/v2_main_v024_rtx6000ada/audit \
  --human outputs/v2_main_v024_rtx6000ada/audit/human_a.csv \
  --second-human outputs/v2_main_v024_rtx6000ada/audit/human_b.csv \
  --adjudicated-human outputs/v2_main_v024_rtx6000ada/audit/human_adjudicated.csv
```

The paper gate becomes ready only when the audit is from the main run, contains at
least four scenes per category, has two raters, and has no unresolved atomic
disagreement. `human_case_metrics.csv` and the human rows in
`audit_metric_summary.csv` are primary; the automatic run is secondary. Preserve the
original rater files and report inter-rater agreement before adjudication.

## 10. Insert measured results into the manuscript

```bash
python -m paraseedbench.export_paper_v2 \
  --input outputs/v2_main_v024_rtx6000ada \
  --audit outputs/v2_main_v024_rtx6000ada/audit
cd manuscript
pdflatex main_v2.tex
pdflatex main_v2.tex
```

Or upload `manuscript/` to Overleaf and select **main_v2.tex**. The official ICASSP
`spconf.sty` is included. The guarded exporter copies a human-primary table and an
evaluator-agreement table, plus the full-suite automatic table as explicitly secondary.
It refuses development results, a mismatched run/audit, one-rater labels, unresolved
disagreements, or an undersized main audit. Replace pending-results prose with measured
findings, add prespecified qualitative examples, and recompile. Do not submit the
draft unchanged.

The current PDF has four technical pages plus a fifth reference-only page, no page
numbers, and 10-point body text. Adding results can change pagination. A LaTeX guard
rejects technical content spilling beyond page four. Complete real author names,
affiliations and required submission metadata; ICASSP 2027 is not blind-reviewed.
See https://cmsworkshops.com/ICASSP2027/papers/paper_kit.php .

## What is scientifically new in v2

The two disagreement scores are not treated as isolated wording/noise effects.
The code computes the exact empirical decomposition into wording, seed and interaction,
plus held-out selected-worst sensitivity, all-wordings correctness, full-support
smoothed JSD, exclusive-control discrimination, and explicit diversity eligibility.
JSD is exploratory; this release does not implement or validate seed-inaccessible APIs.
Scene-bootstrap intervals are conditional on the finite tested grid, not universal
robustness bounds. See REVIEW_AND_REVISION.md and manuscript/main_v2.tex.

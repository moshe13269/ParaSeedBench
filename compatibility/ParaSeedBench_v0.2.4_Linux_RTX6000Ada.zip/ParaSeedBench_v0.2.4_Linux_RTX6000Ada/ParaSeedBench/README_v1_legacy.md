# ParaSeedBench

ParaSeedBench measures whether text-to-image models preserve required semantics across meaning-equivalent prompt wordings and random samples. It deliberately separates:

1. **Reproducibility:** identical prompt and freshly reset noise seed.
2. **Wording sensitivity:** equivalent prompts with the same noise seed.
3. **Sampling sensitivity:** one prompt across different seeds.
4. **Distributional shift:** semantic outcome distributions across wordings when a seed cannot be controlled.
5. **Valid diversity:** DINOv2 distance computed only among images that satisfy every requested atom.

The included v1 suite contains 96 scenes, four equivalent wordings per scene, four diagnostic categories, eight main seeds, and optional meaning-changing counterfactual controls. The full configuration produces 3,840 images per model: `96 x (4 equivalent + 1 counterfactual) x 8 seeds`. The default three-model run therefore produces 11,520 images.

## Important scientific status

This package contains a methods-complete manuscript draft, not a fabricated results paper. `manuscript/main.tex` clearly marks the result section as pending. After a successful run, the analysis command writes the LaTeX table consumed by the manuscript.

The scene suite is generated deterministically from controlled templates. Before publication, two authors should manually audit all 384 equivalent prompt pairs for semantic equivalence and grammar. The automatic evaluator must also be validated against the included stratified human-audit protocol.

## Windows 11 and RTX 3070 setup

Use Python 3.11 and an up-to-date NVIDIA driver. In PowerShell:

```powershell
py -3.11 -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip setuptools wheel
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128
pip install -r requirements.txt
python -m paraseedbench.check_install
pytest -q
```

If the installed driver does not support the CUDA 12.8 PyTorch wheel, select a compatible Windows/CUDA command from the official PyTorch installer. Do not install a CPU-only `torch` wheel by accident. The first run downloads several large model checkpoints and therefore needs adequate disk space.

SDXL uses model CPU offload, and PixArt-Sigma uses sequential CPU offload, to fit an 8 GB GPU. These modes reduce GPU memory use but increase wall time and require sufficient system RAM. Do not enable `torch.compile` for the benchmark unless the same setting is fixed and documented for all repeated runs.

## Build and inspect the benchmark

From the repository root:

```powershell
python -m paraseedbench.build_suite --output data/scenes_v1.jsonl
Get-Content data\scenes_v1.manifest.json
```

The generated file is already included. Rebuilding it verifies that the checked-in suite matches the source templates.

## Run the mandatory smoke test

```powershell
.\run_smoke.ps1
```

The smoke configuration evaluates four scenes, two seeds, and the first model. Inspect every generated image and the semantic-score CSV before starting the expensive run. Tune an evaluator threshold only on this development pilot. Freeze all thresholds before the main run.

The script first repeats one identical prompt/seed three times and records pixel-array hashes in `outputs/smoke/repeatability/sd15/report.json`. A mismatch means the environment is not pixel deterministic; do not silently interpret an integer seed as exact run-to-run reproduction.

## Run the main study

```powershell
.\run_main.ps1
```

Or execute each stage separately:

```powershell
python -m paraseedbench.generate --config configs/main.yaml
python -m paraseedbench.evaluate --input outputs/main
python -m paraseedbench.embed --input outputs/main --batch-size 8
python -m paraseedbench.analyze `
  --scores outputs/main/semantic_scores.csv `
  --embeddings outputs/main/dino_embeddings.npz `
  --output-dir outputs/main/analysis `
  --paper-table manuscript/generated/results_table.tex
```

Every generation has an adjacent JSON record containing its prompt, expected atoms, model, seed, inference settings, elapsed time, and configuration hash. Existing image/metadata pairs are skipped, so interrupted runs can resume safely. Use `--overwrite` only when intentionally replacing a run.

For exact fixed-noise pairing, the code constructs a **fresh CPU `torch.Generator` for every image**. Reusing the same generator object would advance its state and invalidate the comparison.

## Human evaluator audit

Create a blinded, stratified sample:

```powershell
python -m paraseedbench.audit `
  --scores outputs/main/semantic_scores.csv `
  --output outputs/main/audit/human_a.csv `
  --n 240
```

Copy the blank audit file for a second annotator. Annotators fill `human_all_correct` with `0` or `1`; `human_atom_state` is optional but recommended. Score the agreement:

```powershell
python -m paraseedbench.score_audit `
  --human outputs/main/audit/human_a.csv `
  --second-human outputs/main/audit/human_b.csv `
  --machine-key outputs/main/audit/human_a_machine_key.csv `
  --output outputs/main/audit/agreement.json
```

Do not tune the detector or color classifier on main-test labels. If the automated evaluator is inadequate, report human results as primary for a predefined subset and automated results as exploratory.

## Metrics

For scene `c`, wording `j`, and seed `s`, the generator produces `x[c,j,s]`. The evaluator maps it to a binary semantic state containing object, count, color-binding, and relation atoms.

- **Mean accuracy:** fraction of images satisfying all atoms.
- **Robust accuracy:** for each scene, the minimum accuracy over its four wordings, then averaged over scenes.
- **Wording disagreement:** mean pairwise normalized Hamming distance between semantic states across wordings at a fixed seed.
- **Seed disagreement:** the corresponding distance across seeds for a fixed wording.
- **Semantic JSD:** pairwise Jensen-Shannon divergence between wording-conditioned state distributions, with stated Jeffreys smoothing. It emulates seed-inaccessible APIs but is descriptive with eight samples.
- **Valid diversity:** mean pairwise DINOv2 cosine distance among fully correct generations; the eligible pair count is retained.

Confidence intervals use a non-parametric bootstrap over scenes. Model differences use paired scenes. Images and image pairs are not treated as independent experimental units.

The analysis also writes a category-level robust-accuracy figure. Once you choose a representative failure case without cherry-picking the quantitative conclusion, create a qualitative grid with:

```powershell
python -m paraseedbench.example_grid `
  --scores outputs/main/semantic_scores.csv `
  --model sdxl --case-id spatial_000 `
  --output outputs/main/analysis/spatial_000_grid.png
```

## Reproducibility limits

- Equal integer seeds are meaningful only within a specific model/pipeline configuration; they are not common semantic latents across architectures.
- GPU kernels, package versions, and hardware can still affect exact pixels. `run_info.json` records the environment.
- Same-seed image differences are not automatically failures: different valid images are allowed. Semantic correctness and valid diversity are reported separately.
- OWLv2/CLIP mistakes can bias all downstream metrics. Human validation is required.
- Eight seeds support aggregate benchmark conclusions, not precise per-prompt probability estimates.

## Repository layout

```text
configs/                 smoke and main experiment configurations
data/                    frozen benchmark suite and manifest
manuscript/              ICASSP LaTeX draft
src/paraseedbench/       generation, evaluation, analysis, and audit code
tests/                   CPU-only unit tests
run_smoke.ps1            end-to-end development pilot
run_main.ps1             full run after protocol freeze
```

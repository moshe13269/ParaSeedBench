"""ParaSeedBench: controlled semantic reliability evaluation for T2I models."""

__version__ = "0.2.4"

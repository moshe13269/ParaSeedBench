"""Finite-grid descriptive estimands, not a random-effects variance estimator."""
from itertools import combinations, product
import numpy as np
from scipy.spatial.distance import jensenshannon


def decomposition(q):
    q = np.asarray(q, dtype=float)
    if q.ndim != 3 or min(q.shape[:2]) < 2 or q.shape[2] < 1 or not np.isin(q, [0, 1]).all():
        raise ValueError("Expected binary [wording, seed, atom] grid with J,S >= 2")
    j, s, _ = q.shape
    mu = q.mean(axis=(0, 1), keepdims=True)
    a = q.mean(axis=1, keepdims=True) - mu
    b = q.mean(axis=0, keepdims=True) - mu
    interaction = q - mu - a - b
    vw, vs, vi = float((a*a).mean()), float((b*b).mean()), float((interaction*interaction).mean())
    return {"variance_wording": vw, "variance_seed": vs, "variance_interaction": vi,
            "variance_total": float(((q - mu)**2).mean()),
            "wording_disagreement": 2*j/(j-1)*(vw+vi),
            "seed_disagreement": 2*s/(s-1)*(vs+vi)}


def crossfit_worst(a):
    """Two-way split; select wording on one half, score on the other. Not an unbiased minimum."""
    a = np.asarray(a, dtype=float)
    halves = [np.arange(0, a.shape[1], 2), np.arange(1, a.shape[1], 2)]
    if not len(halves[1]):
        return np.nan
    return float(np.mean([a[np.argmin(a[:, train].mean(axis=1)), test].mean()
                          for train, test in (halves, halves[::-1])]))


def state_jsd(q, alpha=0.5):
    q = np.asarray(q, dtype=int)
    support = list(product((0, 1), repeat=q.shape[2]))
    if len(support) > 4096:
        raise ValueError("Too many atoms for enumerated semantic-state JSD")
    probabilities = []
    for wording in q:
        states = [tuple(row) for row in wording]
        counts = np.array([states.count(state) for state in support]) + alpha
        probabilities.append(counts / counts.sum())
    return float(np.mean([jensenshannon(a, b, base=2)**2 for a, b in combinations(probabilities, 2)]))


def stratified_ci(values, categories, rng, n_boot=2000):
    values, categories = np.asarray(values, float), np.asarray(categories)
    if n_boot < 100:
        raise ValueError("Use at least 100 bootstrap draws")
    labels = sorted(set(categories))
    arrays = [values[categories == label] for label in labels]
    arrays = [a[np.isfinite(a)] for a in arrays]
    # Undefined metric in an entire category must not silently reweight the target.
    if any(len(a) == 0 for a in arrays) or not arrays:
        return np.nan, np.nan, np.nan
    estimate = float(np.mean([a.mean() for a in arrays]))
    draws = np.stack([a[rng.integers(0, len(a), size=(n_boot, len(a)))].mean(axis=1) for a in arrays]).mean(axis=0)
    return estimate, *np.percentile(draws, [2.5, 97.5]).tolist()

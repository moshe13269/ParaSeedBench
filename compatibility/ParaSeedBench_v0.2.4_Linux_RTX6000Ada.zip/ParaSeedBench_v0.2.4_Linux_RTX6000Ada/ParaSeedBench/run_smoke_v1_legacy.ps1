$ErrorActionPreference = "Stop"

python -m paraseedbench.check_install
python -m paraseedbench.build_suite --output data/scenes_v1.jsonl
python -m paraseedbench.repeatability --config configs/smoke.yaml --repeats 3
python -m paraseedbench.generate --config configs/smoke.yaml
python -m paraseedbench.evaluate --input outputs/smoke
python -m paraseedbench.embed --input outputs/smoke --batch-size 4
python -m paraseedbench.analyze `
  --scores outputs/smoke/semantic_scores.csv `
  --embeddings outputs/smoke/dino_embeddings.npz `
  --output-dir outputs/smoke/analysis

Write-Host "Smoke test complete. Inspect outputs/smoke before the main run."
